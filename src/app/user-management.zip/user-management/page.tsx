"use client"; // Add this directive at the top of the file

import Link from "next/link";
import { ContentLayout } from "@/components/admin-panel/content-layout";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { DataTable } from "./data-table";
import { userData } from "../../data/userData";
import { Payment, columns } from "./columns";
import { Button } from "@/components/ui/button";
import { Drawer, DrawerTrigger, DrawerContent, DrawerHeader, DrawerTitle, DrawerFooter } from "@/components/ui/drawer";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useState } from "react";

export default function UserManagement() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [roleName, setRoleName] = useState("");
  const [rolePermissions, setRolePermissions] = useState<string[]>([]);

  const permissionsOptions = ["read", "write", "delete", "manage_users"];

  const handleAddUser = () => {
    const newUser = {
      userName,
      userEmail,
      roleName,
      rolePermissions,
    };
    console.log("New User Added:", newUser); // Replace with your logic to add the user to the data
    setIsDrawerOpen(false); // Close the drawer after submission
    // Reset form fields
    setUserName("");
    setUserEmail("");
    setRoleName("");
    setRolePermissions([]);
  };

  return (
    <ContentLayout title="User Management">
      <div className="flex justify-between items-center">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <Drawer open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
                <DrawerTrigger asChild>
                  <Button variant="outline">Add User</Button>
                </DrawerTrigger>
                <DrawerContent>
                  <DrawerHeader>
                    <DrawerTitle>Add New User</DrawerTitle>
                  </DrawerHeader>
                  <div className="p-4 space-y-4">
                    <div>
                      <Label htmlFor="userName">User Name</Label>
                      <Input
                        id="userName"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        placeholder="Enter user name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="userEmail">User Email</Label>
                      <Input
                        id="userEmail"
                        value={userEmail}
                        onChange={(e) => setUserEmail(e.target.value)}
                        placeholder="Enter user email"
                      />
                    </div>
                    <div>
                      <Label htmlFor="roleName">Role Name</Label>
                      <Select onValueChange={(value) => setRoleName(value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="editor">Editor</SelectItem>
                          <SelectItem value="viewer">Viewer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Role Permissions</Label>
                      <div className="space-y-2">
                        {permissionsOptions.map((permission) => (
                          <div key={permission} className="flex items-center space-x-2">
                            <Checkbox
                              id={permission}
                              checked={rolePermissions.includes(permission)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setRolePermissions([...rolePermissions, permission]);
                                } else {
                                  setRolePermissions(rolePermissions.filter((p) => p !== permission));
                                }
                              }}
                            />
                            <Label htmlFor={permission}>{permission}</Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <DrawerFooter>
                    <Button onClick={handleAddUser}>Add User</Button>
                    <Button variant="outline" onClick={() => setIsDrawerOpen(false)}>
                      Cancel
                    </Button>
                  </DrawerFooter>
                </DrawerContent>
              </Drawer>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/">Home</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/dashboard">Dashboard</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>User Management</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <Drawer open={isDrawerOpen} onOpenChange={setIsDrawerOpen}>
          <DrawerTrigger asChild>
            <Button>Add User</Button>
          </DrawerTrigger>
        </Drawer>
      </div>
      <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
        <DataTable columns={columns} data={userData} />
      </div>
    </ContentLayout>
  );
}
export interface Permission {
  sectionId: string;
  create: boolean;
  read: boolean;
  update: boolean;
  delete: boolean;
}

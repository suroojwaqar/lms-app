export interface Section {
    _id: string
    name: string
    path: string
    icon?: string
    parentId?: string | null
  }
  
  
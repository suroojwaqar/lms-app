"use client";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface AttributeModalProps {
  mode: "add" | "edit";
  attribute?: { _id: string; title: string; parentId: string | null; status: string }; // Optional for "add" mode
  parentAttributes: { _id: string; title: string }[]; // List of parent attributes
  onSave: (data: { _id?: string; title: string; parentId: string | null; status: string }) => void;
  children?: React.ReactNode; // Trigger button
}

export function AttributeModal({
  mode,
  attribute,
  parentAttributes,
  onSave,
  children,
}: AttributeModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState(attribute?.title || "");
  const [parentId, setParentId] = useState<string | null>(attribute?.parentId || null);
  const [status, setStatus] = useState(attribute?.status || "active"); // Default status
  const { toast } = useToast();

  const handleSave = async () => {
    if (!title) {
      toast({
        title: "Error",
        description: "Please fill in the title field.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Call the `onSave` function with the data
      await onSave({ _id: attribute?._id, title, parentId, status });

      // Close the modal
      setIsOpen(false);

      // Clear the form fields (only in "add" mode)
      if (mode === "add") {
        setTitle("");
        setParentId(null);
        setStatus("active");
      }

      // Show a success Toast
      toast({
        title: "Success",
        description:
          mode === "add" ? "Attribute added successfully!" : "Attribute updated successfully!",
      });
    } catch (err) {
      console.error("Error saving attribute:", err);
      toast({
        title: "Error",
        description: `Failed to ${mode === "add" ? "add" : "update"} attribute. Please try again.`,
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children || <Button variant="default">{mode === "add" ? "Add New" : "Edit"}</Button>}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{mode === "add" ? "Add New Attribute" : "Edit Attribute"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter title"
            />
          </div>
          <div>
            <Label htmlFor="status">Status</Label>
            <Select
              value={status}
              onValueChange={(value) => setStatus(value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="parentId">Parent Attribute</Label>
            <Select
              value={parentId || ""}
              onValueChange={(value) => setParentId(value || null)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a parent attribute" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {parentAttributes.map((attribute) => (
                  <SelectItem key={attribute._id} value={attribute._id}>
                    {attribute.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleSave} className="btn-fill primary float-right">Save</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
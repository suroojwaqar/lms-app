"use client";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ColumnDef } from "@tanstack/react-table";
import { Copy, EllipsisVertical, Pencil, Trash2 } from "lucide-react";
import { DataTableColumnHeader } from "@/components/data-table/DataTableColumnHeader";
import { Checkbox } from "@/components/ui/checkbox";
import { AttributeModal } from "./AttributeModal";

export type Attribute = {
  _id: string;
  title: string;
  type: string; // Derived from the URL parameter
  parentId: string | null;
  status: string;
  dateCreated: string;
};

export const attributeColumns = (
  deleteItem: (id: string) => void,
  editItem: (data: { _id: string; title: string; parentId: string | null; status: string }) => void,
  parentAttributes: { _id: string; title: string }[]
): ColumnDef<Attribute>[] => [
  {
    id: "select",
    header: ({ table }) => (
      <Checkbox
        checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
        onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
        aria-label="Select all"
      />
    ),
    cell: ({ row }) => (
      <Checkbox
        checked={row.getIsSelected()}
        onCheckedChange={(value) => row.toggleSelected(!!value)}
        aria-label="Select row"
      />
    ),
    enableSorting: false,
    enableHiding: false,
  },
  {
    accessorKey: "title",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Title" />
    ),
  },
  {
    accessorKey: "type.name",
    header: "Type",
  },
  {
    accessorKey: "parentId",
    header: "Parent Attribute",
    cell: ({ row }) => {
      const parentAttribute = parentAttributes.find((attribute) => attribute._id === row.original.parentId);
      return parentAttribute ? parentAttribute.title : "None";
    },
  },
  {
    accessorKey: "status",
    header: "Status",
  },
  {
    accessorKey: "dateCreated",
    header: "Date",
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const attribute = row.original;

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <EllipsisVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="p-2">
            <DropdownMenuItem
              onClick={() => navigator.clipboard.writeText(attribute._id)}
            >
              <Copy className="mr-2 h-4 w-4" />
              Copy ID
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <AttributeModal
              mode="edit"
              attribute={attribute}
              parentAttributes={parentAttributes}
              onSave={(data) =>
                editItem({
                  _id: data._id!,
                  title: data.title,
                  parentId: data.parentId,
                  status: data.status
                })
              }
            >
              <Button variant="ghost" className="w-full justify-start">
                <Pencil className="mr-2 h-4 w-4" />
                Edit
              </Button>
            </AttributeModal>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-red-500"
              onClick={() => deleteItem(attribute._id)}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];
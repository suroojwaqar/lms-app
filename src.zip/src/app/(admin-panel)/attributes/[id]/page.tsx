"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Attribute, AttributeType, AttributeFormData } from "@/types/attribute";
import { ContentLayout } from "@/components/admin-panel/content-layout";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { InDataTable } from "@/components/data-table/InDataTable";
import { attributeColumns } from "./attributeColumns";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { AttributeModal } from "./AttributeModal";
import { Button } from "@/components/ui/button";
import { attributesService } from "@/services/attributes.service";

export default function AttributePage() {
  const params = useParams();
  const typeId = params.id as string;
  const [data, setData] = useState<Attribute[]>([]);
  const [parentAttributes, setParentAttributes] = useState<Attribute[]>([]);
  const [attributeType, setAttributeType] = useState<AttributeType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [typeData, attributesData] = await Promise.all([
          attributesService.getAttributeType(typeId),
          attributesService.getAttributes(typeId)
        ]);

        setAttributeType(typeData);
        setData(attributesData);
        setParentAttributes(attributesData.filter((attr: Attribute) => !attr.parentId));
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [typeId]);

  const handleAddAttribute = async (formData: AttributeFormData) => {
    try {
      const newAttribute = await attributesService.createAttribute(formData, typeId);
      setData(prev => [...prev, newAttribute]);
      toast({ title: "Success", description: "Attribute added successfully!" });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to add attribute",
        variant: "destructive",
      });
    }
  };

  const deleteItem = async (id: string) => {
    try {
      const confirmDelete = window.confirm("Are you sure you want to delete this attribute?");
      if (!confirmDelete) return;

      await attributesService.deleteAttribute(id);
      setData((prevData) => prevData.filter((attribute) => attribute._id !== id));
      toast({
        title: "Success",
        description: "Attribute deleted successfully!",
      });
    } catch (err) {
      console.error("Error deleting attribute:", err);
      toast({
        title: "Error",
        description: "Failed to delete attribute. Please try again.",
        variant: "destructive",
      });
    }
  };

  const editItem = async (updatedData: { _id: string; title: string; parentId: string | null; status: string }) => {
    try {
      const result = await attributesService.updateAttribute(updatedData._id, { ...updatedData, type: typeId });
      setData((prevData) =>
        prevData.map((attribute) =>
          attribute._id === updatedData._id ? { ...attribute, ...result } : attribute
        )
      );

      toast({
        title: "Success",
        description: "Attribute updated successfully!",
      });
    } catch (err) {
      console.error("Error updating attribute:", err);
      toast({
        title: "Error",
        description: "Failed to update attribute. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <ContentLayout title={`${attributeType?.name || "Loading"} Attributes`}>
      <Toaster />
      <div className="flex justify-between items-center mb-4">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link href="/dashboard">Dashboard</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Attributes</BreadcrumbPage>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{attributeType?.name || "Loading"}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <AttributeModal mode="add" parentAttributes={parentAttributes} onSave={handleAddAttribute}>
          <Button className="btn-fill primary">Add New</Button>
        </AttributeModal>
      </div>

      <section className="flex items-start justify-between mb-5">
        <div>
          <h1 className="text-2xl mb-3">{attributeType?.name || "Loading"} List</h1>
          <p className="text-xs text-muted-foreground">All {attributeType?.name || "Loading"} go here</p>
        </div>
      </section>

      <InDataTable columns={attributeColumns(deleteItem, editItem, parentAttributes)} data={data} />
    </ContentLayout>
  );
}
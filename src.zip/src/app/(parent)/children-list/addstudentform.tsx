"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { CalendarIcon } from "lucide-react"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { useState } from "react"

const formSchema = z.object({
  studentName: z.string().min(2, {
    message: "Student name must be at least 2 characters.",
  }),
  dateOfBirth: z.date({
    required_error: "A date of birth is required",
  }),
  gender: z.string(),
  class: z.string(),
  image: z.instanceof(File).optional(),
})

export default function AddStudentForm() {
  const [selectedClass, setSelectedClass] = useState<string>("")
  const [selectedGender, setSelectedGender] = useState<string>("")
  const [previewImage, setPreviewImage] = useState<string>("")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      studentName: "",
      dateOfBirth: undefined,
      gender: "",
      class: "",
      image: undefined,
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values)
    // Here you would typically make an API call to save the student
    // After successful submission, you can close the modal
    // You might want to add a proper API integration here
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      form.setValue("image", file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setPreviewImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="w-full">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="max-w-md mx-auto space-y-6 p-6">
          <FormField
            control={form.control}
            name="image"
            render={({ field: { value, onChange, ...field } }) => (
              <FormItem>
                <FormLabel>Student Image</FormLabel>
                <FormControl>
                  <div className="space-y-4">
                    <Input 
                      type="file" 
                      accept="image/*"
                      onChange={handleImageChange}
                    />
                    {previewImage && (
                      <div className="mt-2">
                        <img 
                          src={previewImage} 
                          alt="Preview" 
                          className="w-32 h-32 object-cover rounded-full"
                        />
                      </div>
                    )}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="studentName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Student Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter student name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="dateOfBirth"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Date of birth</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      disabled={(date) =>
                        date > new Date() || date < new Date("1900-01-01")
                      }
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="gender"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Gender</FormLabel>
                <FormControl>
                  <div className="grid grid-cols-3 gap-2">
                    {["Male", "Female", "Other"].map((gender) => (
                      <Button
                        key={gender}
                        type="button"
                        variant={selectedGender === gender.toLowerCase() ? "default" : "outline"}
                        onClick={() => {
                          setSelectedGender(gender.toLowerCase())
                          field.onChange(gender.toLowerCase())
                        }}
                        className="w-full"
                      >
                        {gender}
                      </Button>
                    ))}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="class"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Select Class</FormLabel>
                <FormControl>
                  <div className="grid grid-cols-3 gap-2">
                    {[1, 2, 3, 4, 5].map((classNum) => (
                      <Button
                        key={classNum}
                        type="button"
                        variant={selectedClass === classNum.toString() ? "default" : "outline"}
                        onClick={() => {
                          setSelectedClass(classNum.toString())
                          field.onChange(classNum.toString())
                        }}
                        className="w-full"
                      >
                        Class {classNum}
                      </Button>
                    ))}
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" className="w-full">Submit</Button>
        </form>
      </Form>
    </div>
  )
}

export interface AttributeType {
  _id: string;
  name: string;
  dateCreated: string;
  __v?: number;
}

export interface CreateAttributeTypeDto {
  name: string;
}

export interface UpdateAttributeTypeDto {
  _id: string;
  name: string;
}

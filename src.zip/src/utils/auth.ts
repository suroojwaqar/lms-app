export function getAuthToken(): string {
  const userStore = localStorage.getItem("user");
  if (!userStore) throw new Error("No user data found. Please log in.");

  const user = JSON.parse(userStore);
  const token = user.access_token;
  if (!token) throw new Error("No token found. Please log in.");

  return token;
}

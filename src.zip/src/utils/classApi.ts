import { getAuthToken } from '@/utils/auth';
import { Class, ClassFormData } from '@/types/class';

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

class ClassApi {
  async getClasses(): Promise<Class[]> {
    console.log(`${BASE_URL}classes`);
    
    const response = await fetch(`${BASE_URL}classes`, {
      headers: {
        Authorization: `Bearer ${getAuthToken()}`
      }
    });
    console.log(response,'response');
    
    if (!response.ok) throw new Error('Failed to fetch classes');
    return response.json();
  }

  async createClass(data: ClassFormData): Promise<Class> {
    const response = await fetch(`${BASE_URL}classes`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error('Failed to create class');
    return response.json();
  }

  async updateClass(id: string, data: ClassFormData): Promise<Class> {
    const response = await fetch(`${BASE_URL}classes/${id}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error('Failed to update class');
    return response.json();
  }

  async deleteClass(id: string): Promise<void> {
    const response = await fetch(`${BASE_URL}classes/${id}`, {
      method: 'DELETE',
      headers: {
        Authorization: `Bearer ${getAuthToken()}`
      }
    });
    if (!response.ok) throw new Error('Failed to delete class');
  }
}

export const classApi = new ClassApi();

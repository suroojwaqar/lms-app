import { CreateAttributeTypeDto, AttributeType, UpdateAttributeTypeDto } from "@/types/attribute-type";
import { getAuthToken } from "@/utils/auth";

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;

const getAuthHeader = () => {
  

  return {
    Authorization: `Bearer ${getAuthToken()}`  };
};

export const attributeTypeApi = {


  getAll: async (): Promise<AttributeType[]> => {
    console.log(getAuthToken(), "getAuthToken()");
    
    
     const response = await fetch(`${BASE_URL}attribute-types`, {
       headers: {
         Authorization: `Bearer ${getAuthToken()}`
       }
     });
     console.log(response, "response");

     if (!response.ok) throw new Error("Failed to fetch classes");
     return response.json();
  
  },

  create: async (data: CreateAttributeTypeDto): Promise<AttributeType> => {
    const response = await fetch(`${BASE_URL}attribute-types`, {
      method: "POST",
      headers: getAuthHeader(),
      body: JSON.stringify({ ...data, dateCreated: new Date().toISOString() }),
    });

    console.log(response, "response");
    

    if (!response.ok) {
      throw new Error(`Failed to add item: ${response.statusText}`);
    }

    return response.json();
  },

  update: async ({ _id, ...data }: UpdateAttributeTypeDto): Promise<AttributeType> => {
    const response = await fetch(`${BASE_URL}attribute-types/${_id}`, {
      method: "PATCH",
      headers: getAuthHeader(),
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      throw new Error(`Failed to update item: ${response.statusText}`);
    }

    return response.json();
  },

  delete: async (id: string): Promise<void> => {
    const response = await fetch(`${BASE_URL}attribute-types/${id}`, {
      method: "DELETE",
      headers: getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error(`Failed to delete item: ${response.statusText}`);
    }
  },
};
